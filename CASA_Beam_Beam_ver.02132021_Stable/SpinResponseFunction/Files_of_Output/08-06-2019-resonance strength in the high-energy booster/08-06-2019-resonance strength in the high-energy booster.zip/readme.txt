\Delta\phi = 0.0093 mrad rms

\Delta y = 0.0033 mm rms


from 9.0 to 13 GeV in 0.1 GeV steps