\Delta\phi = 0.038 mrad rms
\Delta y = 0.007 mm rms


from 1.1 to 8.9 GeV in 0.1 GeV steps