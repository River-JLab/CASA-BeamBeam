
    Thanks for using Luminosity of JLab-CASA Beam-Beam.



    The Luminosity result is put it into the folder "luminosity/Files_of_Output".
    "Luminosity.casa" is a text-format file which can be open by any text-editer.

    Unit of Luminosity is 1/(cm^2*s)

    For "Luminosity.casa", each row means one turn or kicing;

    the 1st column is "Numerical  Luminosity",
    the 2nd column is "Numerical Reduction Factor",
    the 3rd column is "Analytic_1 Luminosity"
    the 4th column is "Analytic_2 Luminosity"
    the 5th column is "Analytic_3 Luminosity"

    Note:
    Analytic Luminosity results are based on the different colliding bunchs' conditions.
    Please read "Analytic_Luminosity_Calculation.pdf" for more details.


    -- River Huang and Vasiliy Morozov at Jefferson Lab