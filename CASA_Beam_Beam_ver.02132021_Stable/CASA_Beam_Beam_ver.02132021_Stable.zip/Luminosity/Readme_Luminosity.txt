Thanks for using "Luminosity" of CASA Beam-Beam.

If you already have RMS-size data, please rename it to "sigma_beam1.casa" and "sigma_beam2.casa" and make sure all RMS-size data are put into folder  "Files_of_Input".

If you don't have RMS-size data, "Luminosity" of CASA Beam-Beam will generate RMS-size data besed on the parameters you offered. 
