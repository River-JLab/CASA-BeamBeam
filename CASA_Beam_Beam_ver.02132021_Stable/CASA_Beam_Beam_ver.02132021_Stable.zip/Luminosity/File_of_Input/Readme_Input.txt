"sigma_beam1.casa" and "sigma_beam2.casa" are the text files.
The unit of RMS-size is (m).

Each line of the data means one turn; belows are the information of columns:
the 1st column is "sigma_x",
the 2nd column is "sigma_y",
the 3rd column is "sigma_z".
