1. Open a terminal in windows or linux system, then run
    python Examples_of_Generating_Loading_Saving_SDDS_Data.py


River and Vasiliy
2018

