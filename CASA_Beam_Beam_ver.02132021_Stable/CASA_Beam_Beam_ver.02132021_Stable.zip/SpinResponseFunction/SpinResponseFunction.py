#  This is the fuction code used for Spin Response Function
#  Vasiliy and River, 2019

import os
import sys

os.system("python3 SpinResponseFunction_Instruction.py")
os.system("python3 SpinResponseFunction_parameter_input.py")
os.system("python3 SRF_and_SRS_calculation.py")


# os.system("gnuplot generate_SRF_figure.gp &")
# os.system("gnuplot plot_SRF.gp &")


print('')
print('**************************************************************')
print('*                                                            *')
print('*  Spin Response Function Calculation is completed. Thanks.  *')
print('*                                                            *')
print('**************************************************************')
print('')

