! -*- Mode: F77; F90; -*-
!
! Copyright(c) Microsoft Corporation.All rights reserved.
! Licensed under the MIT License.
!
       INTEGER MPI_AINT
       PARAMETER (MPI_AINT=z'4c00083b')
       INTEGER MPI_ADDRESS_KIND
       PARAMETER(MPI_ADDRESS_KIND = 8)
